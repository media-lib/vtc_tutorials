#include <stdio.h>
#include <assert.h>

main()
{
	assert(NULL);
	printf("Hello World\n");
}
