#include <stdio.h>

int main (int argc, char *argv[])
{

	int i = 0;


	for (i = 1;i <= 10; i++)
 	{
		printf("%d ah ha!\n", i);	
	}

}
