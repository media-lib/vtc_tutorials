main() {

	register int r=0;

	for (r=0; r<100; r++)
		printf("r=%d\n",r);
}