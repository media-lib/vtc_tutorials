main()
{
	char greet[][8]={"Hello",
			"Hola",
			"Bonjour",
			"Ciao"};

	puts(greet[0]);
	puts(greet[1]);
	puts(greet[2]);
	puts(greet[3]);
}

